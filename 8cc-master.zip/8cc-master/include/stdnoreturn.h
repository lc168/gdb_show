// Copyright 2012 Rui Ueyama. Released under the MIT license.

#ifndef __STDNORETURN_H
#define __STDNORETURN_H

#define noreturn _Noreturn

#endif
