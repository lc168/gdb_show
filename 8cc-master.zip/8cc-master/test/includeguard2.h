// Copyright 2014 Rui Ueyama. Released under the MIT license.

#ifndef INCLUDEGUARD2_H
#endif
