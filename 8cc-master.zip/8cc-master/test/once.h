// Copyright 2014 Rui Ueyama. Released under the MIT license.

#ifdef ONCE_H
#error "#pragma once bug"
#endif

#pragma once
#define ONCE_H 1
