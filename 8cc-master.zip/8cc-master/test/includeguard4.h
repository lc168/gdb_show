// Copyright 2014 Rui Ueyama. Released under the MIT license.

#ifndef INCLUDEGUARD4_H
#define INCLUDEGUARD4_H
#else
#endif
