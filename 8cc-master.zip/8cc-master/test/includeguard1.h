// Copyright 2014 Rui Ueyama. Released under the MIT license.

#ifndef INCLUDEGUARD1_H
#define INCLUDEGUARD1_H
#endif
