// Copyright 2012 Rui Ueyama. Released under the MIT license.

#ifdef IMPORT_H
#error "#import directive bug"
#endif

#define IMPORT_H 1
