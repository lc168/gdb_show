// Copyright 2014 Rui Ueyama. Released under the MIT license.

#ifndef INCLUDEGUARD6_H
#define INCLUDEGUARD6_H
#include "includeguard7.h"
