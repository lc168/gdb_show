// Copyright 2014 Rui Ueyama. Released under the MIT license.

#define FOO
#ifndef INCLUDEGUARD5_H
#define INCLUDEGUARD5_H
#endif
