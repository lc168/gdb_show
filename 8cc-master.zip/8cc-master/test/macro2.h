// Copyright 2012 Rui Ueyama. Released under the MIT license.

#define MACRO_2 "macro2"
