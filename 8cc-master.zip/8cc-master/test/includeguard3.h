// Copyright 2014 Rui Ueyama. Released under the MIT license.

#ifndef INCLUDEGUARD3_H
#define INCLUDEGUARD3_H
#endif

#define FOO 1
